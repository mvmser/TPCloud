package com.efrei.JPA_Rent;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaRentApplicationTests {

	@Test
	void contextLoads() {
	}

}
