> Add your entities here:
> * Vehicle
> * Car
> * Van
> * Person
> * Rent